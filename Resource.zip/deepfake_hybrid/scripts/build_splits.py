import argparse
import sys
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.append(str(SRC))

from utils import load_config, ensure_dir, effective_name


def main():
    parser = argparse.ArgumentParser(description="Build train/val/test splits by video")
    parser.add_argument("--config", required=True)
    parser.add_argument("--dataset", choices=["FFPP", "CDF"], help="Dataset name")
    parser.add_argument("--val-size", type=float, default=0.15)
    parser.add_argument("--test-size", type=float, default=0.15)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--method", type=str, default=None,
                        choices=["Deepfakes", "Face2Face", "FaceSwap", "NeuralTextures"],
                        help="FFPP only: use method-specific manifest")
    args = parser.parse_args()

    cfg = load_config(args.config)
    eff_name = effective_name(args.dataset, args.method)
    manifest_path = Path(cfg["output_root"]) / "manifests" / eff_name / "manifest.csv"
    if not manifest_path.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_path}. Run extract_frames.py first.")

    df = pd.read_csv(manifest_path)
    duplicate_ids = df[df["video_id"].duplicated()]["video_id"].unique().tolist()
    if duplicate_ids:
        preview = ", ".join(duplicate_ids[:10])
        raise ValueError(
            "Duplicate video_id values found in manifest. "
            f"Re-run extract_frames.py after updating IDs, then rebuild splits. Examples: {preview}"
        )

    # Validate minimum samples per class for stratified split
    class_counts = df["label"].value_counts()
    min_per_class = 4  # need at least 1 per split (train/val/test) + margin
    for label_val, count in class_counts.items():
        if count < min_per_class:
            raise ValueError(
                f"Class {label_val} has only {count} samples — need at least {min_per_class} "
                f"for a stratified 70/15/15 split. Increase --n-samples."
            )
    print(f"Class distribution: {dict(class_counts)}")

    train_val, test = train_test_split(df, test_size=args.test_size, stratify=df["label"], random_state=args.seed)
    train, val = train_test_split(train_val, test_size=args.val_size / (1 - args.test_size), stratify=train_val["label"], random_state=args.seed)

    out_dir = Path(cfg["output_root"]) / "manifests" / eff_name
    ensure_dir(out_dir)
    train.to_csv(out_dir / "train.csv", index=False)
    val.to_csv(out_dir / "val.csv", index=False)
    test.to_csv(out_dir / "test.csv", index=False)
    print(f"Saved splits to {out_dir}")


if __name__ == "__main__":
    main()
